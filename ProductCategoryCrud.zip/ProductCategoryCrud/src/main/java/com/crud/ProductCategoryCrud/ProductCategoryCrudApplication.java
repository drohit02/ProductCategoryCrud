package com.crud.ProductCategoryCrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCategoryCrudApplication {

	public static void main(String[] args) {

		SpringApplication.run(ProductCategoryCrudApplication.class, args);
	}

}
